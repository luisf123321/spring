package com.example.obspringrest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ObSpringRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
