package com.example.obspringsecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ObSpringSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
