package com.example.obspringsecuritycrifrado;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ObSpringSecurityCrifradoApplicationTests {

	@Test
	void contextLoads() {
	}

}
