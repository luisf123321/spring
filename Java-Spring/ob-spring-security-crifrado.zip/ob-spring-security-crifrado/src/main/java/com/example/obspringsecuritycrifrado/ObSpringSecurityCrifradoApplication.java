package com.example.obspringsecuritycrifrado;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ObSpringSecurityCrifradoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ObSpringSecurityCrifradoApplication.class, args);
	}

}
