package org.example;

public class Saludo {

    public void imprimirSaludo(){
        System.out.println("hello world");
    }
}
